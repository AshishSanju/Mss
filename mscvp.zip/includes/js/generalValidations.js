/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
  function Formvalidation(datefrom,dateto){ 
      
      //alert("hiiiiiiii");
      
          if(((datefrom == "") && (dateto != ""))|| (datefrom != "") && (dateto == "")){
                 alert("Please enter Date Start and Date To");
                return false;
      }else if(datefrom != "" && dateto != ""){
             
                    return compareDates1(datefrom,dateto);
               
          }else{
              return true;    
          }
        
      
      
  }


function compareDates1(start,end){  
 //alert("start  in general--->"+start+"--------end---------"+end);       
    var startDate = start;             
    var endDate =end;
    var sDate=new Date(startDate);            
    var eDate=new Date(endDate);
    
    if(sDate>eDate){
        alert("DateFrom must less than DateTo!");
        return false;
    }
    else
        return true;
};

/**
 * Ristrict the manual entry in date From And date to fields
 * 
 * 
 */
function enterDate()
{
    alert("Please select from the Calender !");
    document.getElementById('podatepickerfrom').value='';
}