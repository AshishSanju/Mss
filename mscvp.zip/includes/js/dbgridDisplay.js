/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function hideSearch(){
    
	if(document.getElementById("searchdiv").style.display == 'none') {
		document.getElementById("searchdiv").style.display="block";
		document.getElementById("fsCollImg").src = "../includes/images/dtp/cal_plus.gif";
	}else{
		document.getElementById("searchdiv").style.display="none";
		document.getElementById("fsCollImg").src = "../includes/images/dtp/cal_minus.gif";
	}
}

function showonlyGird(){
	document.getElementById("searchdiv").style.display="none";
	document.getElementById("fsCollImg").src = "../includes/images/dtp/cal_minus.gif";
}
